console.log("page loaded...");

function over(vid){
        vid.play();
}
function out(element){
    element.pause();
    element.currentTime = 0
}


