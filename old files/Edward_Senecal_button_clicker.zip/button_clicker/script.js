function login(element){
    element.innerText = "Logout";
}
function def(element){
    element.remove();
}
